# oop_game
Oop game, three words are:
  * Squirrel
  * Crown
  * Fire
